class RouteLocation {
  RouteLocation._();

  static String get home => '/home';
  static String get createTask => '/createTask';
}
