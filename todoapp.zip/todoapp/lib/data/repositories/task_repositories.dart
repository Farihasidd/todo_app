import '../data.dart';

abstract class TaskRepository {
  Future<void> createTask(Task Task);
  Future<void> updateTask(Task Task);
  Future<void> deleteTask(Task Task);
  Future<List<Task>> getAllTasks();
}
